#include "Game.h"

/*
* TODO:

*/

int main() {
    Game game;

    game.Run();

    return 0;
}